<?php
/* * *********************************************************
 * [cmlphp] (C)2012 - 3000 http://cmlphp.com
 * @Author  linhecheng<linhechengbush@live.com>
 * @Date: 15-7-3 下午3:07
 * @version  @see \Cml\Cml::VERSION
 * cmlphp框架 系统默认服务类
 * *********************************************************** */
namespace Cml;


/**
 * 系统默认的Server类
 *
 * @package Cml
 */
class Server extends Controller
{

}
