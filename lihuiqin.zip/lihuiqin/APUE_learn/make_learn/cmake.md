## CMake是什么？
- 全称Cross Platform Make。
- 工程构建工具

## 优势
- 开放源代码
- 跨平台
- 语言简单
- 高效、可扩展
