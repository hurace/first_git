#ifndef TOOL2_H_
#define TOOL2_H_
void mytool2(void);
#endif
