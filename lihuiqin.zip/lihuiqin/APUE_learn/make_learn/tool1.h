#ifndef TOOL1_H_
#define TOOL1_H_
void mytool1(void);
#endif
