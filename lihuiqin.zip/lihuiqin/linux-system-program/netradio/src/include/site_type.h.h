#ifndef SITETYPE_H__
#define SITETYPE_H__

#include <stdint.h>

typedef uint8_t chnid_t;

#endif

