#include <stdio.h>
#include <stdlib.h>

int main()
{

    puts(getenv("PATH"));



    exit(0);
}
