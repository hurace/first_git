#ifndef PROTO_H__
#define PROTO_H__

#define SERVERPORT      "1989"
#define FMT_STAMP       "%lld"



#endif