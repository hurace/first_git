#include<stdio.h>
int main(void)
{
	double b = 1.25;
	int arr[100];

	b++;
	printf("%f",b);
	printf("%d",sizeof(arr));
}
