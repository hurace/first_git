#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    bool a = true;

    printf("a = %d\n", a);

    exit(0);
}