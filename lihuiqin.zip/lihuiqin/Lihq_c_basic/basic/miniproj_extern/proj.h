#ifndef PROJ_H_
#define PROJ_H_

void func();

#endif