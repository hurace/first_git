#ifndef PROJ_H_
#define PROJ_H_

void call_func();
static void func();

#endif