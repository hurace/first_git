#include <stdio.h>
#include <stdlib.h>

//  TYPE NAME = VALUE

int main()
{
    int* p = NULL;
    void* q = NULL;
    //int* p;

    printf("p = %p\n", p);
    printf("*p = %d\n", *p);

    exit(0);
}