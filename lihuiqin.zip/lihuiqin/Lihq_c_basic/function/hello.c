#include <stdio.h>
#include <stdlib.h>

void print_hello();

int main()
{
    print_hello();

    exit(0);
}

void print_hello()
{
    printf("hello world\n");

    return;
}