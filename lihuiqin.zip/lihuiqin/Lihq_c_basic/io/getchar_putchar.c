#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ch;

    ch = getchar();
    putchar(ch);
    putchar('\n');

    exit(0);
}