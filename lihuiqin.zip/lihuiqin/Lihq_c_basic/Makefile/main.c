#include <stdio.h>
#include <stdlib.h>

#include "tool1.h"
#include "tool2.h"

int main()
{
    mytool1();
    mytool2();

    exit(0);
}