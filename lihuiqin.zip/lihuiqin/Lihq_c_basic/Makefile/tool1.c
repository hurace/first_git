#include <stdio.h>

#include "tool1.h"

void mytool1()
{
    printf("tool1 print\n\n");
}