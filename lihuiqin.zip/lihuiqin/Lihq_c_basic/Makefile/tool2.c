#include <stdio.h>

#include "tool2.h"

void mytool2()
{
    printf("tool2 print\n");
}