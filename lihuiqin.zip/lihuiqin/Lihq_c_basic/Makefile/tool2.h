#ifndef TOOL2_H__
#define TOOL2_H__

void mytool2();

#endif