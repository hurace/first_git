#ifndef TOOL1_H__
#define TOOL1_H__

void mytool1();

#endif